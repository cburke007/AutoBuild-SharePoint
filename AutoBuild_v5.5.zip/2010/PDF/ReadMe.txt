You can pre-download the Adobe PDF iFilter from here: http://download.adobe.com/pub/adobe/acrobat/win/9.x/PDFiFilter64installer.zip

The official PDF icon is available here: http://helpx.adobe.com/content/dam/kb/en/837/cpsid_83709/attachments/AdobePDF.png


Place the .zip (or the extracted .msi) in this folder along with the AdobePDF.png, and AutoSPInstaller can automatically install them in order to be able to index PDF files and display the icon properly in SharePoint search results, document libraries, etc.